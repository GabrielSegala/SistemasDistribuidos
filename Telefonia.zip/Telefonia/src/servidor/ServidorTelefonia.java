
package servidor;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

import model.Sessao;
import model.TabelaHash;
import utilidades.Util;

public class ServidorTelefonia {

    private static final int PORTA = 5000;
    private static final String ARQUIVO = "telephony_sessions.txt";

    private final TabelaHash tabela = new TabelaHash();

    public ServidorTelefonia(String caminhoArquivo)
            throws IOException {

        StringBuilder dados = new StringBuilder();

        String erro = Util.carregarArquivoEmHashMap(
                caminhoArquivo,
                tabela.sessoes,
                dados
        );

        if (erro != null && !erro.isEmpty()) {
            throw new IOException(erro);
        }

        System.out.println("Sessoes carregadas: "
                + tabela.sessoes.size());
    }

    public void iniciar() throws IOException {

        ServerSocket servidor = new ServerSocket(PORTA);

        System.out.println(
                "Servidor aguardando conexoes na porta " + PORTA
        );

        while (true) {
            Socket cliente = servidor.accept();

            Thread atendimento = new Thread(
                    () -> atenderCliente(cliente)
            );

            atendimento.start();
        }
    }

    private void atenderCliente(Socket socket) {

        try (
            Socket cliente = socket;
            BufferedReader entrada = new BufferedReader(
                    new InputStreamReader(
                            cliente.getInputStream(),
                            StandardCharsets.UTF_8
                    )
            );
            PrintWriter saida = new PrintWriter(
                    cliente.getOutputStream(),
                    true,
                    StandardCharsets.UTF_8
            )
        ) {
            String numero = entrada.readLine();

            if (numero == null || numero.trim().isEmpty()) {
                saida.println("ERRO: numero invalido");
                return;
            }

            Sessao sessao = tabela.sessoes.get(numero.trim());

            if (sessao != null) {
                saida.println(sessao.getDadosSessao());
            } else {
                saida.println("NOT_FOUND");
            }

        } catch (IOException e) {
            System.err.println(
                    "Erro no atendimento: " + e.getMessage()
            );
        }
    }

    public static void main(String[] args) {

        try {
            ServidorTelefonia servidor =
                    new ServidorTelefonia(ARQUIVO);

            servidor.iniciar();

        } catch (IOException e) {
            System.err.println(
                    "Erro ao iniciar servidor: " + e.getMessage()
            );
        }
    }
}
