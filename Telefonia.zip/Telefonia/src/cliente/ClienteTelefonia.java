
package cliente;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class ClienteTelefonia {

    private static final String SERVIDOR = "localhost";
    private static final int PORTA = 5000;

    public static void main(String[] args) {

        try (Scanner teclado = new Scanner(System.in)) {

            System.out.print("Digite o numero do celular: ");
            String numero = teclado.nextLine().trim();

            try (
                Socket socket = new Socket(SERVIDOR, PORTA);
                BufferedReader entrada = new BufferedReader(
                    new InputStreamReader(
                        socket.getInputStream(),
                        StandardCharsets.UTF_8));
                PrintWriter saida = new PrintWriter(
                    socket.getOutputStream(),
                    true,
                    StandardCharsets.UTF_8)
            ) {
                saida.println(numero);

                String resposta = entrada.readLine();

                if (resposta == null) {
                    System.out.println("Servidor encerrou a conexao.");
                } else if ("NOT_FOUND".equals(resposta)) {
                    System.out.println("Numero nao encontrado.");
                } else if (resposta.startsWith("ERRO:")) {
                    System.out.println(resposta);
                } else {
                    System.out.println("Dados da sessao:");
                    System.out.println(resposta);
                }

            } catch (IOException e) {
                System.out.println(
                    "Nao foi possivel conectar ao servidor.");
                System.out.println(e.getMessage());
            }

        }
    }
}
